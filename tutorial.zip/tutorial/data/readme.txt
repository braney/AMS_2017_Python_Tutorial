Data files from http://www.esrl.noaa.gov/psd/data/gridded/data.ncep.reanalysis.surface.html
